const fetch = require('node-fetch');
const fs = require('fs');
module.exports = (client) => {
    client.handleCrashDump = (name) => {
       
    /*    const fileName = "./src/data/dump.txt";
        
        const string = name;
        try{
            fs.writeFileSync(fileName,string);
            return true;
        } catch (error){
            console.log(error)
            return false;
        }*/
    } 
}



